import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Mile_Converter extends PApplet {

public void setup() {
  size(740,400);
}

public void draw() {
  background(255);
  drawReference(0,50);
  float mile = mileConverter(mouseX);
  float km = kmConverter(mouseX);
  rect(0,50,mouseX,50);
  fill(0);
  text(mile,100,15);
  text("Miles:",30,15);
  text(km, 100,25);
  text("Kilometers:",30,25);
}

public float mileConverter(float km) {
  float miles = km * .62137f;
  return miles;
}

public float kmConverter(float mile) {
  float km = mile * 1;
  return km;
}  

public void drawReference (int xpos, int ypos) {
  stroke(200);
  line(xpos-50, ypos, 900, ypos);
  for(int i = 0; i<800; i=i+50) {
    text(i, xpos+i-8, ypos);
    line(xpos+i, ypos, xpos +i, ypos+5);
  }
}  
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Mile_Converter" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
